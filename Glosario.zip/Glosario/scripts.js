// Glosario de términos
const glosario = {
    "Blockchain": "Es un registro digital descentralizado y distribuido que almacena transacciones en bloques, asegurando que no puedan ser alteradas sin el consenso de la red.",
    "Experiencia de usuario": 
    "Se refiere a cómo un usuario interactúa con un producto o servicio, enfocándose en la facilidad de uso, la satisfacción y la percepción general.",
    "JSON": "Es un formato en el cual se puede guardar e intercambiar la información que cualquier persona pueda leer. Por lo tanto, los archivos Json contienen solo texto y estos utilizan la extensión. json.",
    "API RESTFUL": 
    "Es un tipo específico de API que sigue los principios REST (Transferencia de Estado Representacional). Utiliza métodos HTTP para realizar operaciones sobre recursos identificados por URLs, permitiendo interacciones simples y eficientes entre sistemas.",
    "Ejemplo página web 2.0 y 3.0": 
    "Web 2.0: Ejemplo: Facebook, donde los usuarios generan contenido y pueden interactuar entre sí. Web 3.0: Ejemplo: Aplicaciones descentralizadas (dApps) como Ethereum, que permiten a los usuarios interactuar sin intermediarios y con mayor control sobre sus datos.",
    "SPA, página de ejemplo": 
    "SPA (Single Page Application) es una aplicación web que carga una única página HTML y actualiza dinámicamente el contenido. Ejemplo: Gmail.",
    "PWA": 
    "Es una aplicación en la cual utilizan Apis y funciones emergentes del navegador web junto a una estrategia tradicional de mejora progresiva como la experiencia del usuario para aplicaciones web. Como ejemplo se tiene el Trello en el cual utiliza un enfoque muy similar al del Gmail, en donde permite a los usuarios gestionar proyectos sin necesidad de recargas constantes.",
    "Dirección ip": "Una dirección IP es un número único que identifica un dispositivo en una red, facilitando la comunicación entre dispositivos conectados a internet.",
    "Responsiva o adaptativa?": "Diseño responsivo ajusta el contenido a cualquier tamaño de pantalla automáticamente. Diseño adaptativo usa diferentes layouts fijos para distintos tamaños de pantalla.",
    "Transferencia de datos": "La transferencia de datos es el proceso de enviar información de un lugar a otro a través de una red.",
    "Versión beta": "Una versión BETA de un software es una versión preliminar, aún en pruebas, antes de su lanzamiento oficial.",
    "Hospedaje web": "Hospedaje Web es el servicio que permite almacenar un sitio web en un servidor para que esté disponible en internet.",
    "Dominio": "Un dominio es la dirección única que identifica a un sitio web en la red, por ejemplo, www.ejemplo.com.",
    "Subdominio": "Un subdominio es una extensión del dominio principal, como blog.ejemplo.com.",
    "Ssh": "SSH (Secure Shell) es un protocolo para acceder de manera segura a un servidor remoto.",
    "Ftp": "FTP (File Transfer Protocol) es un protocolo de red utilizado para transferir archivos entre computadoras.",
    "Base de datos relacional": "Una base de datos relacional organiza los datos en tablas con relaciones definidas entre ellas.",
    "Base de datos no relacional": "Una base de datos no relacional almacena datos de manera más flexible, por ejemplo, en documentos o gráficos, sin relaciones fijas entre los datos.",
    "Token": "Un token es un elemento de autenticación que permite acceder de manera segura a un sistema.",
    "Disponibilidad": "Disponibilidad se refiere a la capacidad de un sistema de estar accesible cuando se necesita.",
    "Integridad": "Integridad significa mantener y asegurar que los datos son correctos y completos en todo momento.",
    "Confidencialidad": "Confidencialidad es la garantía de que la información solo está disponible para aquellos que tienen permiso para acceder a ella.",
    "Control de versiones": "El control de versiones es el proceso de gestionar diferentes versiones de un proyecto o documento a lo largo del tiempo.",
    "Accesibilidad": "Accesibilidad es la práctica de hacer sitios web utilizables para todas las personas, incluidas aquellas con discapacidades.",
    "Documentación": "La documentación en desarrollo de software se refiere a los manuales y guías que describen cómo funciona un sistema o aplicación.",
    "Css": "CSS (Cascading Style Sheets) es el lenguaje utilizado para definir el estilo visual de los documentos HTML.",
    "Html": "HTML (HyperText Markup Language) es el lenguaje estándar para estructurar y presentar contenido en la web.",
    "JavaScript": "JavaScript es un lenguaje de programación que permite hacer páginas web interactivas.",
    "Documento web": "Un documento web es cualquier archivo o página que se puede acceder a través de un navegador web, como archivos HTML.",
    "Elementos básicos de documentos web": "Los elementos básicos incluyen títulos, párrafos, imágenes, enlaces, listas y tablas que componen la estructura de una página web.",
    "Formularios": "Los formularios en HTML permiten a los usuarios enviar datos a un servidor mediante diferentes controles como cajas de texto, botones y menús desplegables.",
    "Método get y post": "El método GET envía los datos a través de la URL, mientras que POST envía los datos de forma más segura dentro del cuerpo de la solicitud.",
    "Selectores": "Los selectores en CSS son patrones utilizados para seleccionar y aplicar estilos a elementos específicos en un documento HTML.",
    "Modelo de caja": "El modelo de caja en CSS describe cómo se representan los elementos HTML como cajas, que incluyen márgenes, bordes, rellenos y el contenido."
};

// Función para buscar la palabra en el glosario
function buscarPalabra() {
    const input = document.getElementById('input-glosario').value.trim();
    const resultado = document.getElementById('resultado');
    
    if (input === "") {
        resultado.innerHTML = "<p>Por favor, ingrese una palabra para buscar.</p>";
        return;
    }
    
    const definicion = glosario[input];
    
    if (definicion) {
        resultado.innerHTML = `<p>${definicion}</p>`;
    } else {
        resultado.innerHTML = "<p>La palabra no se encuentra en el glosario.</p>";
    }
}